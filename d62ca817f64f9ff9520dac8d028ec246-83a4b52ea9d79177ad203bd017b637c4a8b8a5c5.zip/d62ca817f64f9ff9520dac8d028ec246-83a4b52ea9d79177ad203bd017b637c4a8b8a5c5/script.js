function calculateMetrics() {
    // Get input values
    const inputs = {
        averageOrderValue: parseFloat(document.getElementById('averageOrderValue').value),
        purchaseFrequency: parseFloat(document.getElementById('purchaseFrequency').value),
        ppcCPA: parseFloat(document.getElementById('ppcCPA').value),
        targetMarketing: parseFloat(document.getElementById('targetMarketing').value) / 100,
        existingCustomers: parseFloat(document.getElementById('existingCustomers').value) / 100
    };

    // Calculate true CPA
    const trueNewCustomerCPA = inputs.ppcCPA / (1 - inputs.existingCustomers);
    
    // Calculate yearly metrics
    const yearlyRevenue = inputs.averageOrderValue * inputs.purchaseFrequency;
    let yearlyCalculationsHTML = '';
    let cumulativeRevenue = 0;

    for (let year = 1; year <= 5; year++) {
        cumulativeRevenue += yearlyRevenue;
        const roas = cumulativeRevenue / trueNewCustomerCPA;
        const maxCPA = cumulativeRevenue * inputs.targetMarketing;

        yearlyCalculationsHTML += `
            <tr>
                <td>${year}</td>
                <td>£${yearlyRevenue.toFixed(2)}</td>
                <td>£${cumulativeRevenue.toFixed(2)}</td>
                <td>${roas.toFixed(2)}x</td>
                <td>£${maxCPA.toFixed(2)}</td>
            </tr>
        `;
    }

    // Calculate CPA analysis
    const maxProfitableCPA = cumulativeRevenue * inputs.targetMarketing;
    const headroom = maxProfitableCPA - trueNewCustomerCPA;
    const possibleIncrease = (headroom / trueNewCustomerCPA) * 100;

    // Update DOM
    document.getElementById('trueCustomerCPA').textContent = `£${trueNewCustomerCPA.toFixed(2)}`;
    document.getElementById('yearlyCalculations').innerHTML = yearlyCalculationsHTML;
    document.getElementById('totalRevenue').textContent = `£${cumulativeRevenue.toFixed(2)}`;
    document.getElementById('maxProfitableCPA').textContent = `£${maxProfitableCPA.toFixed(2)}`;
    document.getElementById('currentCPA').textContent = `£${trueNewCustomerCPA.toFixed(2)}`;
    document.getElementById('headroom').textContent = `£${headroom.toFixed(2)}`;
    document.getElementById('possibleIncrease').textContent = `${possibleIncrease.toFixed(1)}%`;
}

// Add event listeners to all inputs
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', calculateMetrics);
});

// Initial calculation
calculateMetrics();